<?php
 

class State {
    
    const NO_SUCURSALES        = '10000';
      
    const LIST_SUCURSALES      = '10001';
      
    const SINGLE_PRICELIST     = '20000';
      
    const MULTIPLE_PRICELIST   = '20001';
      
    const UPDATE_PRICELIST     = '30000';
    
    const PARAM_ERROR          = '70000';
    
}

?>